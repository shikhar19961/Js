const name = "Shikhar"
const repoCount = 5
console.log(`hello my name is ${name} and repo count is${repoCount}`)

const gameName = new String('Shikhar-uttam')

console.log(gameName.toUpperCase());
console.log(gameName.charAt(2));
console.log(gameName.indexOf("k"));
const newSting = gameName.substring(0,4);
const newSlice = gameName.slice(0,-6);
const neStr = "   Shikhar"
console.log(neStr);
const neStrTrimmed = "   uttam"
console.log(neStrTrimmed.trim());
console.log('%20shikhar'.replace('%20','-'));




