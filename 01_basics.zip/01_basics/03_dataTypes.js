"use strict"; //tread all js code as new version

//alert(3+3) // we are using nodejs not browser

console.log(3
    +
    3)//Code readability should be high

let name = "Shikhar"
let age = 18
let isLoggedIn = true

// number - 2- to power 53
// bigint - 
// string => ""
// boolean => true/false
// null => stanalone value - representation of empty value
// undefined => if value is not assigned then it undefined
// symbol => unique 
// object 
console.log(typeof "");
console.log(typeof age);
console.log(typeof null); // return object type
console.log(typeof undefined); // return undefined

