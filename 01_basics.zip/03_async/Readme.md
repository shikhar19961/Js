--------> Javascript
        -> Synchronous
        -> Single Threaded

--------> Execution Context
        -> Synchronouse execute one line of code at a time
        each operation waits for the last one
        to complete before executing
        -> Asynchronouse - Code keeps on executing and other
        process are running at the background