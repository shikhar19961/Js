 
 var array = [1,2,3,4]
 for (let index = 0; index < array.length; index++) {
    
 }

 console.log(index);